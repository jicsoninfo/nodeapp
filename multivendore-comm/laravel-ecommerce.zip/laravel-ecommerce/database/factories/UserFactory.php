<?php

namespace Database\Factories;

use App\Enums\UserStatus;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Str;

class UserFactory extends Factory
{
    protected $model = User::class;

    private static ?string $password = null;

    public function definition(): array
    {
        return [
            'email'             => fake()->unique()->safeEmail(),
            'phone'             => fake()->unique()->numerify('+1##########'),
            'password'          => self::$password ??= Hash::make('Password@123'),
            'status'            => UserStatus::Active,
            'email_verified_at' => now(),
            'remember_token'    => Str::random(10),
        ];
    }

    public function unverified(): static
    {
        return $this->state(fn () => ['email_verified_at' => null]);
    }

    public function suspended(): static
    {
        return $this->state(fn () => ['status' => UserStatus::Suspended]);
    }

    public function pending(): static
    {
        return $this->state(fn () => ['status' => UserStatus::Pending, 'email_verified_at' => null]);
    }
}
