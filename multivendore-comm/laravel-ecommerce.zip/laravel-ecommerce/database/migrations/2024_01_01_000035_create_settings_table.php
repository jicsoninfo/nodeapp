<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('settings', function (Blueprint $table) {
            $table->id();
            $table->string('key', 255)->unique();
            $table->longText('value')->nullable();
            $table->string('type', 50)->default('string');   // string|boolean|integer|json
            $table->string('group', 100)->default('general');
            $table->string('description', 500)->nullable();
            $table->timestamps();

            $table->index('group');
        });
    }

    public function down(): void { Schema::dropIfExists('settings'); }
};
