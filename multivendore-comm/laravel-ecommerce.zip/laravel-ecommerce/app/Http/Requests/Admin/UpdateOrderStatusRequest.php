<?php
namespace App\Http\Requests\Admin;
use App\Enums\OrderStatus;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rules\Enum;

class UpdateOrderStatusRequest extends FormRequest
{
    public function authorize(): bool { return true; }
    public function rules(): array
    {
        return [
            'status' => ['required', new Enum(OrderStatus::class)],
            'reason' => 'nullable|string|max:500',
        ];
    }
}
