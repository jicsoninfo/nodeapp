<?php
namespace App\Events\Product;
use App\Models\Product;
use Illuminate\Foundation\Events\Dispatchable;
use Illuminate\Queue\SerializesModels;

class ProductApproved
{
    use Dispatchable, SerializesModels;
    public function __construct(public readonly Product $product) {}
}
