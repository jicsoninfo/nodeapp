const NodeCache = require('node-cache');

// stdTTL in seconds. Mirrors the 300s TTL used on the Laravel side.
const cache = new NodeCache({ stdTTL: 300, checkperiod: 60 });

async function remember(key, ttlSeconds, fn) {
  const cached = cache.get(key);
  if (cached !== undefined) return cached;

  const value = await fn();
  cache.set(key, value, ttlSeconds);
  return value;
}

function forgetUser(userId) {
  cache.del([
    `user:${userId}:role_slugs`,
    `user:${userId}:role_permission_slugs`,
    `user:${userId}:direct_permissions`,
  ]);
}

module.exports = { cache, remember, forgetUser };
