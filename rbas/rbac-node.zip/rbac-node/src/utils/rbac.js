const User = require('../models/User');
const Role = require('../models/Role');
const Permission = require('../models/Permission');
const { remember, forgetUser } = require('../utils/cache');

/**
 * Resolution order (same as the Laravel version):
 *  1. super-admin role -> always allowed.
 *  2. Direct "forbid" override on that permission -> denied, even if a role grants it.
 *  3. Direct "grant" override -> allowed.
 *  4. Otherwise falls back to whatever the user's roles grant.
 */

async function getRoleSlugs(userId) {
  return remember(`user:${userId}:role_slugs`, 300, async () => {
    const user = await User.findById(userId).populate('roleAssignments.role', 'slug');
    if (!user) return [];
    return user.roleAssignments.map((a) => a.role.slug);
  });
}

async function getRolePermissionSlugs(userId) {
  return remember(`user:${userId}:role_permission_slugs`, 300, async () => {
    const user = await User.findById(userId).populate({
      path: 'roleAssignments.role',
      populate: { path: 'permissions', select: 'slug' },
    });
    if (!user) return [];

    const slugs = new Set();
    for (const assignment of user.roleAssignments) {
      for (const perm of assignment.role.permissions) {
        slugs.add(perm.slug);
      }
    }
    return [...slugs];
  });
}

async function getDirectPermissionMap(userId) {
  return remember(`user:${userId}:direct_permissions`, 300, async () => {
    const user = await User.findById(userId).populate('permissionOverrides.permission', 'slug');
    if (!user) return {};

    const map = {};
    for (const override of user.permissionOverrides) {
      map[override.permission.slug] = override.forbidden;
    }
    return map;
  });
}

async function isSuperAdmin(userId) {
  const slugs = await getRoleSlugs(userId);
  return slugs.includes('super-admin');
}

async function hasRole(userId, roleOrRoles) {
  const roles = Array.isArray(roleOrRoles) ? roleOrRoles : [roleOrRoles];
  const slugs = await getRoleSlugs(userId);
  return slugs.some((s) => roles.includes(s));
}

async function hasAllRoles(userId, roles) {
  const slugs = await getRoleSlugs(userId);
  return roles.every((r) => slugs.includes(r));
}

async function hasPermission(userId, slug) {
  if (await isSuperAdmin(userId)) return true;

  const direct = await getDirectPermissionMap(userId);

  if (Object.prototype.hasOwnProperty.call(direct, slug)) {
    return direct[slug] === false; // stored value is "forbidden"; false means granted
  }

  const rolePermissions = await getRolePermissionSlugs(userId);
  return rolePermissions.includes(slug);
}

async function hasAnyPermission(userId, slugs) {
  for (const slug of slugs) {
    if (await hasPermission(userId, slug)) return true;
  }
  return false;
}

async function hasAllPermissions(userId, slugs) {
  for (const slug of slugs) {
    if (!(await hasPermission(userId, slug))) return false;
  }
  return true;
}

async function assignRole(userId, roleSlugOrId, scope = null) {
  const role = roleSlugOrId.match?.(/^[0-9a-fA-F]{24}$/)
    ? await Role.findById(roleSlugOrId)
    : await Role.findOne({ slug: roleSlugOrId });

  if (!role) throw new Error('Role not found');

  const user = await User.findById(userId);
  const alreadyAssigned = user.roleAssignments.some(
    (a) =>
      a.role.toString() === role._id.toString() &&
      String(a.scopeId) === String(scope?.id || null) &&
      a.scopeType === (scope ? scope.type : null)
  );

  if (!alreadyAssigned) {
    user.roleAssignments.push({
      role: role._id,
      scopeId: scope?.id || null,
      scopeType: scope ? scope.type : null,
    });
    await user.save();
  }

  forgetUser(userId);
  return user;
}

async function removeRole(userId, roleSlugOrId) {
  const role = roleSlugOrId.match?.(/^[0-9a-fA-F]{24}$/)
    ? await Role.findById(roleSlugOrId)
    : await Role.findOne({ slug: roleSlugOrId });

  if (!role) throw new Error('Role not found');

  await User.updateOne({ _id: userId }, { $pull: { roleAssignments: { role: role._id } } });
  forgetUser(userId);
}

async function syncRoles(userId, roleIds) {
  await User.updateOne(
    { _id: userId },
    { roleAssignments: roleIds.map((id) => ({ role: id, scopeId: null, scopeType: null })) }
  );
  forgetUser(userId);
}

async function givePermissionTo(userId, permissionSlugOrId) {
  await setOverride(userId, permissionSlugOrId, false);
}

async function forbidPermission(userId, permissionSlugOrId) {
  await setOverride(userId, permissionSlugOrId, true);
}

async function setOverride(userId, permissionSlugOrId, forbidden) {
  const permission = permissionSlugOrId.match?.(/^[0-9a-fA-F]{24}$/)
    ? await Permission.findById(permissionSlugOrId)
    : await Permission.findOne({ slug: permissionSlugOrId });

  if (!permission) throw new Error('Permission not found');

  await User.updateOne({ _id: userId }, { $pull: { permissionOverrides: { permission: permission._id } } });
  await User.updateOne(
    { _id: userId },
    { $push: { permissionOverrides: { permission: permission._id, forbidden } } }
  );

  forgetUser(userId);
}

async function revokePermissionOverride(userId, permissionSlugOrId) {
  const permission = permissionSlugOrId.match?.(/^[0-9a-fA-F]{24}$/)
    ? await Permission.findById(permissionSlugOrId)
    : await Permission.findOne({ slug: permissionSlugOrId });

  if (!permission) throw new Error('Permission not found');

  await User.updateOne({ _id: userId }, { $pull: { permissionOverrides: { permission: permission._id } } });
  forgetUser(userId);
}

module.exports = {
  hasRole,
  hasAllRoles,
  hasPermission,
  hasAnyPermission,
  hasAllPermissions,
  isSuperAdmin,
  assignRole,
  removeRole,
  syncRoles,
  givePermissionTo,
  forbidPermission,
  revokePermissionOverride,
  getRoleSlugs,
  getRolePermissionSlugs,
};
