const jwt = require('jsonwebtoken');
const User = require('../models/User');

function signToken(user) {
  return jwt.sign({ sub: user._id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRES_IN || '8h',
  });
}

async function register(req, res) {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(422).json({ message: 'name, email, and password are required.' });
  }

  const existing = await User.findOne({ email });
  if (existing) {
    return res.status(422).json({ message: 'Email already in use.' });
  }

  const user = await User.create({ name, email, password });

  return res.status(201).json({
    token: signToken(user),
    user: { id: user._id, name: user.name, email: user.email },
  });
}

async function login(req, res) {
  const { email, password } = req.body;

  const user = await User.findOne({ email }).select('+password');
  if (!user || !(await user.comparePassword(password))) {
    return res.status(401).json({ message: 'Invalid credentials.' });
  }

  return res.json({
    token: signToken(user),
    user: { id: user._id, name: user.name, email: user.email },
  });
}

async function me(req, res) {
  const rbac = require('../utils/rbac');
  const roleSlugs = await rbac.getRoleSlugs(req.user.id);
  const permissionSlugs = await rbac.getRolePermissionSlugs(req.user.id);

  return res.json({
    id: req.user._id,
    name: req.user.name,
    email: req.user.email,
    roles: roleSlugs,
    permissions: permissionSlugs,
  });
}

module.exports = { register, login, me };
