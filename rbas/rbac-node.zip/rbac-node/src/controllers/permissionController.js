const Permission = require('../models/Permission');
const Role = require('../models/Role');
const User = require('../models/User');

async function index(req, res) {
  const permissions = await Permission.find().sort({ module: 1, name: 1 });
  res.json(permissions);
}

async function store(req, res) {
  const { name, module, description } = req.body;

  if (!name) return res.status(422).json({ message: 'name is required.' });

  const permission = await Permission.create({ name, module, description });
  res.status(201).json(permission);
}

async function destroy(req, res) {
  const permission = await Permission.findById(req.params.id);
  if (!permission) return res.status(404).json({ message: 'Permission not found.' });

  await Role.updateMany({ permissions: permission._id }, { $pull: { permissions: permission._id } });
  await User.updateMany({}, { $pull: { permissionOverrides: { permission: permission._id } } });
  await permission.deleteOne();

  res.json({ message: 'Permission deleted.' });
}

module.exports = { index, store, destroy };
