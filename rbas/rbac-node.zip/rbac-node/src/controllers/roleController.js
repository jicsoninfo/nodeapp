const Role = require('../models/Role');
const User = require('../models/User');
const { forgetUser } = require('../utils/cache');

async function index(req, res) {
  const roles = await Role.find().populate('permissions', 'slug name module');

  const withCounts = await Promise.all(
    roles.map(async (role) => {
      const userCount = await User.countDocuments({ 'roleAssignments.role': role._id });
      return {
        ...role.toObject(),
        userCount,
        permissionCount: role.permissions.length,
      };
    })
  );

  res.json(withCounts);
}

async function show(req, res) {
  const role = await Role.findById(req.params.id).populate('permissions');
  if (!role) return res.status(404).json({ message: 'Role not found.' });
  res.json(role);
}

async function store(req, res) {
  const { name, description, permissions = [] } = req.body;

  if (!name) return res.status(422).json({ message: 'name is required.' });

  const role = await Role.create({ name, description, permissions });
  res.status(201).json(role);
}

async function update(req, res) {
  const role = await Role.findById(req.params.id);
  if (!role) return res.status(404).json({ message: 'Role not found.' });

  if (role.isSystem) {
    return res.status(403).json({ message: 'System roles cannot be modified.' });
  }

  const { name, description, permissions } = req.body;

  if (name !== undefined) role.name = name;
  if (description !== undefined) role.description = description;
  if (permissions !== undefined) role.permissions = permissions;

  await role.save();

  // Invalidate cached permissions for every user holding this role.
  const affectedUsers = await User.find({ 'roleAssignments.role': role._id }).select('_id');
  affectedUsers.forEach((u) => forgetUser(u._id));

  res.json(role);
}

async function destroy(req, res) {
  const role = await Role.findById(req.params.id);
  if (!role) return res.status(404).json({ message: 'Role not found.' });

  if (role.isSystem) {
    return res.status(403).json({ message: 'System roles cannot be deleted.' });
  }

  const affectedUsers = await User.find({ 'roleAssignments.role': role._id }).select('_id');

  await User.updateMany({ 'roleAssignments.role': role._id }, { $pull: { roleAssignments: { role: role._id } } });
  await role.deleteOne();

  affectedUsers.forEach((u) => forgetUser(u._id));

  res.json({ message: 'Role deleted.' });
}

module.exports = { index, show, store, update, destroy };
