const User = require('../models/User');
const rbac = require('../utils/rbac');

async function index(req, res) {
  const users = await User.find()
    .select('name email roleAssignments')
    .populate('roleAssignments.role', 'name slug');

  res.json(
    users.map((u) => ({
      id: u._id,
      name: u.name,
      email: u.email,
      roles: u.roleAssignments.map((a) => a.role?.name).filter(Boolean),
    }))
  );
}

async function show(req, res) {
  const user = await User.findById(req.params.userId)
    .populate('roleAssignments.role', 'name slug')
    .populate('permissionOverrides.permission', 'name slug module');

  if (!user) return res.status(404).json({ message: 'User not found.' });

  res.json({
    id: user._id,
    name: user.name,
    email: user.email,
    roles: user.roleAssignments,
    permissionOverrides: user.permissionOverrides,
  });
}

async function updateRoles(req, res) {
  const { roleIds = [] } = req.body;

  const user = await User.findById(req.params.userId);
  if (!user) return res.status(404).json({ message: 'User not found.' });

  await rbac.syncRoles(user._id, roleIds);

  res.json({ message: `Roles updated for ${user.name}.` });
}

async function updateOverride(req, res) {
  const { permissionId, action } = req.body; // action: 'grant' | 'forbid' | 'clear'

  const user = await User.findById(req.params.userId);
  if (!user) return res.status(404).json({ message: 'User not found.' });

  if (!['grant', 'forbid', 'clear'].includes(action)) {
    return res.status(422).json({ message: 'action must be grant, forbid, or clear.' });
  }

  if (action === 'grant') await rbac.givePermissionTo(user._id, permissionId);
  if (action === 'forbid') await rbac.forbidPermission(user._id, permissionId);
  if (action === 'clear') await rbac.revokePermissionOverride(user._id, permissionId);

  res.json({ message: `Permission override updated for ${user.name}.` });
}

module.exports = { index, show, updateRoles, updateOverride };
