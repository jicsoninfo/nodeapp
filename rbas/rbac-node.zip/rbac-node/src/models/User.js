const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

// A single role assignment. `scopeId` + `scopeType` let the same role be
// assigned per-branch/company/warehouse in a multi-tenant ERP. Leave null
// for a global assignment.
const roleAssignmentSchema = new mongoose.Schema(
  {
    role: { type: mongoose.Schema.Types.ObjectId, ref: 'Role', required: true },
    scopeId: { type: mongoose.Schema.Types.ObjectId, default: null },
    scopeType: { type: String, default: null }, // e.g. "Branch", "Company"
  },
  { _id: false }
);

// Direct, per-user permission override that bypasses roles entirely.
// forbidden: true explicitly denies, even if a role grants it.
const permissionOverrideSchema = new mongoose.Schema(
  {
    permission: { type: mongoose.Schema.Types.ObjectId, ref: 'Permission', required: true },
    forbidden: { type: Boolean, default: false },
  },
  { _id: false }
);

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, select: false },
    roleAssignments: [roleAssignmentSchema],
    permissionOverrides: [permissionOverrideSchema],
  },
  { timestamps: true }
);

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

userSchema.methods.comparePassword = function (candidate) {
  return bcrypt.compare(candidate, this.password);
};

module.exports = mongoose.model('User', userSchema);
