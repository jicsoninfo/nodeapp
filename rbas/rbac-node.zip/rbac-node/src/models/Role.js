const mongoose = require('mongoose');
const { slugify } = require('./Permission');

const roleSchema = new mongoose.Schema(
  {
    name: { type: String, required: true }, // e.g. "Sales Manager"
    slug: { type: String, required: true, unique: true }, // e.g. "sales-manager"
    description: { type: String },
    isSystem: { type: Boolean, default: false }, // protects core roles (e.g. Super Admin)
    permissions: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Permission' }],
  },
  { timestamps: true }
);

roleSchema.pre('validate', function (next) {
  if (!this.slug && this.name) {
    this.slug = slugify(this.name);
  }
  next();
});

module.exports = mongoose.model('Role', roleSchema);
