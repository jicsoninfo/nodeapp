const mongoose = require('mongoose');

function slugify(str) {
  return str
    .toString()
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)/g, '');
}

const permissionSchema = new mongoose.Schema(
  {
    name: { type: String, required: true }, // e.g. "Sales: Create"
    slug: { type: String, required: true, unique: true }, // e.g. "sales.create"
    module: { type: String, index: true }, // e.g. "Sales", "Inventory", "HR"
    description: { type: String },
  },
  { timestamps: true }
);

permissionSchema.pre('validate', function (next) {
  if (!this.slug && this.name) {
    this.slug = slugify(this.name);
  }
  next();
});

module.exports = mongoose.model('Permission', permissionSchema);
module.exports.slugify = slugify;
