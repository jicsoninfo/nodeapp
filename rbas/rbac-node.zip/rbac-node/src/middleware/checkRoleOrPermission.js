const rbac = require('../utils/rbac');

/**
 * Usage:
 *   router.post('/orders/:id/approve', authenticate, checkRoleOrPermission(['admin', 'sales.approve']), handler)
 * Passes if the user has ANY of the given values as a role OR a permission.
 */
function checkRoleOrPermission(values) {
  const list = Array.isArray(values) ? values : [values];

  return async (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'Unauthenticated.' });

    for (const value of list) {
      if (await rbac.hasRole(req.user.id, value)) return next();
      if (await rbac.hasPermission(req.user.id, value)) return next();
    }

    return res.status(403).json({ message: 'You do not have access to this resource.' });
  };
}

module.exports = checkRoleOrPermission;
