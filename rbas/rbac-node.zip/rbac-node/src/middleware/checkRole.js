const rbac = require('../utils/rbac');

/**
 * Usage:
 *   router.get('/reports', authenticate, checkRole('admin'), handler)
 *   router.get('/reports', authenticate, checkRole(['admin', 'sales-manager']), handler) // any of these
 */
function checkRole(roleOrRoles) {
  return async (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'Unauthenticated.' });

    const allowed = await rbac.hasRole(req.user.id, roleOrRoles);

    if (!allowed) {
      return res.status(403).json({ message: 'You do not have the required role to access this resource.' });
    }

    next();
  };
}

module.exports = checkRole;
