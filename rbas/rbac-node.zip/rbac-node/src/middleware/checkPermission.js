const rbac = require('../utils/rbac');

/**
 * Usage:
 *   router.post('/invoices', authenticate, checkPermission('sales.create'), handler)
 *   router.post('/invoices', authenticate, checkPermission(['sales.create', 'sales.edit']), handler) // requires ALL
 */
function checkPermission(slugOrSlugs) {
  const slugs = Array.isArray(slugOrSlugs) ? slugOrSlugs : [slugOrSlugs];

  return async (req, res, next) => {
    if (!req.user) return res.status(401).json({ message: 'Unauthenticated.' });

    const allowed = await rbac.hasAllPermissions(req.user.id, slugs);

    if (!allowed) {
      return res.status(403).json({ message: 'You do not have permission to perform this action.' });
    }

    next();
  };
}

module.exports = checkPermission;
