require('dotenv').config();
const connectDB = require('../config/db');
const Permission = require('../models/Permission');
const Role = require('../models/Role');
const User = require('../models/User');

const MODULES = {
  Sales: ['view', 'create', 'edit', 'delete', 'approve'],
  Purchase: ['view', 'create', 'edit', 'delete', 'approve'],
  Inventory: ['view', 'create', 'edit', 'delete', 'adjust_stock'],
  Accounting: ['view', 'create', 'edit', 'delete', 'post_journal', 'close_period'],
  HR: ['view', 'create', 'edit', 'delete', 'approve_leave', 'run_payroll'],
  Reports: ['view', 'export'],
};

const SYSTEM_PERMISSIONS = ['roles.manage', 'permissions.manage', 'users.manage_roles', 'settings.manage'];

function titleCase(str) {
  return str.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase());
}

async function upsertPermission(slug, name, module) {
  return Permission.findOneAndUpdate(
    { slug },
    { $setOnInsert: { name, module, slug } },
    { upsert: true, new: true }
  );
}

async function upsertRole(slug, name, description, isSystem = false) {
  return Role.findOneAndUpdate(
    { slug },
    { $setOnInsert: { name, description, slug, isSystem } },
    { upsert: true, new: true }
  );
}

async function run() {
  await connectDB();

  const allPermissionIds = [];
  const bySlug = {};

  for (const [module, actions] of Object.entries(MODULES)) {
    for (const action of actions) {
      const slug = `${module.toLowerCase()}.${action}`;
      const permission = await upsertPermission(slug, `${module}: ${titleCase(action)}`, module);
      allPermissionIds.push(permission._id);
      bySlug[slug] = permission;
    }
  }

  for (const slug of SYSTEM_PERMISSIONS) {
    const [module, action] = slug.split('.');
    const permission = await upsertPermission(slug, `${titleCase(module)}: ${titleCase(action)}`, 'System');
    allPermissionIds.push(permission._id);
    bySlug[slug] = permission;
  }

  // ---- Roles -----------------------------------------------------

  const superAdmin = await upsertRole('super-admin', 'Super Admin', 'Full unrestricted access.', true);
  superAdmin.permissions = allPermissionIds;
  await superAdmin.save();

  const admin = await upsertRole('admin', 'Administrator', 'Manages users, roles, and settings.');
  admin.permissions = [...SYSTEM_PERMISSIONS, 'reports.view', 'reports.export'].map((s) => bySlug[s]._id);
  await admin.save();

  const salesManager = await upsertRole('sales-manager', 'Sales Manager', 'Manages sales and approves orders.');
  salesManager.permissions = Object.entries(bySlug)
    .filter(([slug]) => slug.startsWith('sales.') || slug === 'reports.view')
    .map(([, p]) => p._id);
  await salesManager.save();

  const accountant = await upsertRole('accountant', 'Accountant', 'Manages accounting entries and periods.');
  accountant.permissions = Object.entries(bySlug)
    .filter(([slug]) => slug.startsWith('accounting.') || slug === 'reports.view')
    .map(([, p]) => p._id);
  await accountant.save();

  const warehouseStaff = await upsertRole('warehouse-staff', 'Warehouse Staff', 'Manages stock levels and inventory.');
  warehouseStaff.permissions = Object.entries(bySlug)
    .filter(([slug]) => slug.startsWith('inventory.'))
    .map(([, p]) => p._id);
  await warehouseStaff.save();

  const hrOfficer = await upsertRole('hr-officer', 'HR Officer', 'Manages employee records, leave, and payroll.');
  hrOfficer.permissions = Object.entries(bySlug)
    .filter(([slug]) => slug.startsWith('hr.'))
    .map(([, p]) => p._id);
  await hrOfficer.save();

  const viewer = await upsertRole('viewer', 'Viewer', 'Read-only access across modules.');
  viewer.permissions = Object.entries(bySlug)
    .filter(([, p]) => p.name.endsWith(': View'))
    .map(([, p]) => p._id);
  await viewer.save();

  // ---- Default super admin user -----------------------------------

  const existingSuperUser = await User.findOne({ email: 'admin@example.com' });
  if (!existingSuperUser) {
    const user = await User.create({
      name: 'Super Admin',
      email: 'admin@example.com',
      password: 'ChangeMe123!',
    });
    user.roleAssignments.push({ role: superAdmin._id, scopeId: null, scopeType: null });
    await user.save();
    console.log('Created default super admin: admin@example.com / ChangeMe123!');
  }

  console.log('Seed complete.');
  process.exit(0);
}

run().catch((err) => {
  console.error(err);
  process.exit(1);
});
