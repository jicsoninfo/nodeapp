const express = require('express');
const authenticate = require('../middleware/auth');
const checkPermission = require('../middleware/checkPermission');
const permissionController = require('../controllers/permissionController');

const router = express.Router();

router.use(authenticate, checkPermission('permissions.manage'));

router.get('/', permissionController.index);
router.post('/', permissionController.store);
router.delete('/:id', permissionController.destroy);

module.exports = router;
