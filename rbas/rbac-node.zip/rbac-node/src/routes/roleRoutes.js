const express = require('express');
const authenticate = require('../middleware/auth');
const checkPermission = require('../middleware/checkPermission');
const roleController = require('../controllers/roleController');

const router = express.Router();

router.use(authenticate, checkPermission('roles.manage'));

router.get('/', roleController.index);
router.get('/:id', roleController.show);
router.post('/', roleController.store);
router.put('/:id', roleController.update);
router.delete('/:id', roleController.destroy);

module.exports = router;
