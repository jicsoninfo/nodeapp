const express = require('express');
const authenticate = require('../middleware/auth');
const checkPermission = require('../middleware/checkPermission');
const userRoleController = require('../controllers/userRoleController');

const router = express.Router();

router.use(authenticate, checkPermission('users.manage_roles'));

router.get('/', userRoleController.index);
router.get('/:userId/roles', userRoleController.show);
router.put('/:userId/roles', userRoleController.updateRoles);
router.put('/:userId/permission-override', userRoleController.updateOverride);

module.exports = router;
