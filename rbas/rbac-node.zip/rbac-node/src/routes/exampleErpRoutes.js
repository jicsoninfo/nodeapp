const express = require('express');
const authenticate = require('../middleware/auth');
const checkPermission = require('../middleware/checkPermission');
const checkRoleOrPermission = require('../middleware/checkRoleOrPermission');

const router = express.Router();

// Example: only users with sales.create can create invoices
router.post('/sales/invoices', authenticate, checkPermission('sales.create'), (req, res) => {
  res.json({ message: 'Invoice created (example handler).' });
});

// Example: admins OR anyone with the specific approve permission
router.post(
  '/sales/orders/:id/approve',
  authenticate,
  checkRoleOrPermission(['admin', 'sales.approve']),
  (req, res) => {
    res.json({ message: `Order ${req.params.id} approved (example handler).` });
  }
);

// Example: closing an accounting period requires a very specific permission
router.post(
  '/accounting/periods/:id/close',
  authenticate,
  checkPermission('accounting.close_period'),
  (req, res) => {
    res.json({ message: `Period ${req.params.id} closed (example handler).` });
  }
);

module.exports = router;
