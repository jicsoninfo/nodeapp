# ERP RBAC System — Node.js + Express + MongoDB

The same RBAC design as the Laravel version, ported to Node/Express/Mongoose.
No third-party RBAC package — plain Mongoose models + middleware, JWT auth,
and a short-TTL in-memory cache on permission checks.

## Features

- **Roles** with `isSystem` flag protecting core roles (e.g. Super Admin).
- **Permissions** grouped by ERP module (Sales, Purchase, Inventory, Accounting, HR, Reports).
- **Direct per-user permission overrides** (grant or explicit forbid) that take
  priority over role-based permissions.
- **Scoped role assignment** (`scopeId` / `scopeType` on each role assignment) for
  per-branch/company role assignment in a multi-tenant ERP.
- **Super Admin bypass**.
- Express **middleware**: `checkRole()`, `checkPermission()`, `checkRoleOrPermission()`.
- JWT-based auth (`/api/auth/register`, `/login`, `/me`).
- REST endpoints for managing roles, permissions, and per-user role/permission assignment.
- `node-cache`-backed memoization of permission lookups (300s TTL, invalidated on writes).

## Project structure

```
src/
  config/db.js                     MongoDB connection
  models/{User,Role,Permission}.js Mongoose schemas
  utils/rbac.js                    Core role/permission resolution logic
  utils/cache.js                   Cache wrapper + invalidation helper
  middleware/{auth,checkRole,checkPermission,checkRoleOrPermission}.js
  controllers/{authController,roleController,permissionController,userRoleController}.js
  routes/{authRoutes,roleRoutes,permissionRoutes,userRoleRoutes,exampleErpRoutes}.js
  seed/seed.js                     ERP modules/permissions/roles + a default super admin
  app.js / server.js
```

## Setup

```bash
cd rbac-node
npm install
cp .env.example .env      # edit MONGO_URI / JWT_SECRET as needed
npm run seed               # creates permissions, roles, and admin@example.com / ChangeMe123!
npm run dev                # or `npm start`
```

Server runs on `http://localhost:4000` by default.

## Permission resolution order

1. `super-admin` role → always allowed.
2. Direct **forbid** override on that permission → denied, even if a role grants it.
3. Direct **grant** override → allowed.
4. Otherwise falls back to whatever the user's roles grant.

## API quick reference

### Auth
```
POST /api/auth/register   { name, email, password }
POST /api/auth/login      { email, password } -> { token, user }
GET  /api/auth/me         (Bearer token)      -> { roles, permissions, ... }
```

### Roles (requires `roles.manage` permission)
```
GET    /api/roles
GET    /api/roles/:id
POST   /api/roles          { name, description, permissions: [permissionId, ...] }
PUT    /api/roles/:id
DELETE /api/roles/:id
```

### Permissions (requires `permissions.manage` permission)
```
GET    /api/permissions
POST   /api/permissions    { name, module, description }
DELETE /api/permissions/:id
```

### User role/permission assignment (requires `users.manage_roles` permission)
```
GET  /api/users/:userId/roles
PUT  /api/users/:userId/roles                  { roleIds: [id, ...] }
PUT  /api/users/:userId/permission-override    { permissionId, action: 'grant'|'forbid'|'clear' }
```

### Protecting your own ERP routes

```js
const authenticate = require('./middleware/auth');
const checkPermission = require('./middleware/checkPermission');
const checkRoleOrPermission = require('./middleware/checkRoleOrPermission');

router.post('/sales/invoices', authenticate, checkPermission('sales.create'), handler);
router.post('/sales/orders/:id/approve', authenticate, checkRoleOrPermission(['admin', 'sales.approve']), handler);
```

See `src/routes/exampleErpRoutes.js` for working examples.

## Notes

- Passwords are hashed with bcrypt on save; `password` is `select: false` by default.
- The cache TTL (300s) means role/permission edits can take up to 5 minutes to reflect
  for a given user if you don't call the invalidation helpers — every write path here
  (`assignRole`, `syncRoles`, role update/delete, permission delete, overrides) already
  calls `forgetUser()` for the affected users, so this only matters if you write directly
  to MongoDB outside of `rbac.js`.
- Like the Laravel version, this only governs *what a user can do* — pair it with your
  own `companyId`/`branchId` field + query filters for row-level multi-tenant data
  isolation.
- For production, swap the in-memory `node-cache` for Redis if you run multiple Node
  instances behind a load balancer (in-memory cache is per-process).
