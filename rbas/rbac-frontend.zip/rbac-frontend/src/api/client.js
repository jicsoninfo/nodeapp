const BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:4000/api';

async function request(path, { method = 'GET', body, token } = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));

  if (!res.ok) {
    throw new Error(data.message || `Request failed (${res.status})`);
  }

  return data;
}

export const api = {
  login: (email, password) => request('/auth/login', { method: 'POST', body: { email, password } }),
  register: (name, email, password) =>
    request('/auth/register', { method: 'POST', body: { name, email, password } }),
  me: (token) => request('/auth/me', { token }),

  getRoles: (token) => request('/roles', { token }),
  getRole: (token, id) => request(`/roles/${id}`, { token }),
  createRole: (token, payload) => request('/roles', { method: 'POST', body: payload, token }),
  updateRole: (token, id, payload) => request(`/roles/${id}`, { method: 'PUT', body: payload, token }),
  deleteRole: (token, id) => request(`/roles/${id}`, { method: 'DELETE', token }),

  getPermissions: (token) => request('/permissions', { token }),
  createPermission: (token, payload) => request('/permissions', { method: 'POST', body: payload, token }),
  deletePermission: (token, id) => request(`/permissions/${id}`, { method: 'DELETE', token }),

  getUsers: (token) => request('/users', { token }),
  getUserRoles: (token, userId) => request(`/users/${userId}/roles`, { token }),
  updateUserRoles: (token, userId, roleIds) =>
    request(`/users/${userId}/roles`, { method: 'PUT', body: { roleIds }, token }),
  updateUserOverride: (token, userId, permissionId, action) =>
    request(`/users/${userId}/permission-override`, {
      method: 'PUT',
      body: { permissionId, action },
      token,
    }),
};
