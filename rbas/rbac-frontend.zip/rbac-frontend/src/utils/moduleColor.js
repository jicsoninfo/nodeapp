const MODULE_VARS = {
  Sales: '--mod-sales',
  Purchase: '--mod-purchase',
  Inventory: '--mod-inventory',
  Accounting: '--mod-accounting',
  HR: '--mod-hr',
  Reports: '--mod-reports',
  System: '--mod-system',
};

export function moduleColor(moduleName) {
  const varName = MODULE_VARS[moduleName] || '--mod-system';
  return `var(${varName})`;
}

export function groupByModule(permissions) {
  return permissions.reduce((acc, p) => {
    const key = p.module || 'Other';
    acc[key] = acc[key] || [];
    acc[key].push(p);
    return acc;
  }, {});
}
