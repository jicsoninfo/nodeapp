import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Modal from '../components/Modal';
import { groupByModule, moduleColor } from '../utils/moduleColor';

export default function Permissions() {
  const { token, hasPermission } = useAuth();
  const showToast = useToast();

  const [permissions, setPermissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [creating, setCreating] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(null);

  const canManage = hasPermission('permissions.manage');

  async function refresh() {
    setLoading(true);
    try {
      setPermissions(await api.getPermissions(token));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleDelete(permission) {
    try {
      await api.deletePermission(token, permission._id);
      showToast(`Permission "${permission.slug}" deleted.`);
      setConfirmDelete(null);
      refresh();
    } catch (err) {
      showToast(err.message);
    }
  }

  const grouped = groupByModule(permissions);

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Permissions</h1>
          <p className="subtitle">The individual actions users can be granted across ERP modules.</p>
        </div>
        {canManage && (
          <button className="btn btn-primary" onClick={() => setCreating(true)}>
            + New permission
          </button>
        )}
      </div>

      {loading ? (
        <p className="muted">Loading permissions…</p>
      ) : (
        Object.entries(grouped).map(([module, perms]) => (
          <div key={module} className="card" style={{ marginBottom: 16 }}>
            <div style={{ padding: '16px 20px', borderBottom: '1px solid var(--border)' }} className="flex-row">
              <span className="dot" style={{ width: 8, height: 8, borderRadius: '50%', background: moduleColor(module) }} />
              <h3 style={{ fontSize: 15 }}>{module}</h3>
              <span className="muted" style={{ fontSize: 13 }}>
                {perms.length} permission{perms.length === 1 ? '' : 's'}
              </span>
            </div>
            <div className="table-wrap">
              <table className="data-table">
                <thead>
                  <tr>
                    <th>Slug</th>
                    <th>Name</th>
                    <th>Description</th>
                    {canManage && <th></th>}
                  </tr>
                </thead>
                <tbody>
                  {perms.map((p) => (
                    <tr key={p._id}>
                      <td>
                        <code className="mono" style={{ fontSize: 12.5 }}>
                          {p.slug}
                        </code>
                      </td>
                      <td>{p.name}</td>
                      <td className="muted">{p.description || '—'}</td>
                      {canManage && (
                        <td style={{ textAlign: 'right' }}>
                          <button className="btn btn-ghost" onClick={() => setConfirmDelete(p)}>
                            Delete
                          </button>
                        </td>
                      )}
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        ))
      )}

      {creating && (
        <CreatePermissionModal
          onClose={() => setCreating(false)}
          onSaved={() => {
            setCreating(false);
            refresh();
          }}
        />
      )}

      {confirmDelete && (
        <Modal
          title={`Delete "${confirmDelete.slug}"?`}
          onClose={() => setConfirmDelete(null)}
          footer={
            <>
              <button className="btn btn-secondary" onClick={() => setConfirmDelete(null)}>
                Cancel
              </button>
              <button className="btn btn-danger" onClick={() => handleDelete(confirmDelete)}>
                Delete permission
              </button>
            </>
          }
        >
          <p className="muted" style={{ fontSize: 14 }}>
            This removes the permission from every role and user override that references it.
          </p>
        </Modal>
      )}
    </div>
  );
}

function CreatePermissionModal({ onClose, onSaved }) {
  const { token } = useAuth();
  const showToast = useToast();

  const [name, setName] = useState('');
  const [module, setModule] = useState('Sales');
  const [description, setDescription] = useState('');
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    if (!name.trim()) {
      setError('Permission name is required.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      await api.createPermission(token, { name, module, description });
      showToast(`Permission "${name}" created.`);
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      title="New permission"
      onClose={onClose}
      footer={
        <>
          <button className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button className="btn btn-primary" onClick={handleSubmit} disabled={saving}>
            {saving ? 'Saving…' : 'Create permission'}
          </button>
        </>
      }
    >
      <div className="field">
        <label htmlFor="perm-name">Name</label>
        <input
          id="perm-name"
          className="input"
          placeholder="e.g. Sales: Export report"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
        <span className="hint">Slug is generated automatically from the name.</span>
      </div>
      <div className="field">
        <label htmlFor="perm-module">Module</label>
        <select id="perm-module" className="select" value={module} onChange={(e) => setModule(e.target.value)}>
          {['Sales', 'Purchase', 'Inventory', 'Accounting', 'HR', 'Reports', 'System'].map((m) => (
            <option key={m} value={m}>
              {m}
            </option>
          ))}
        </select>
      </div>
      <div className="field">
        <label htmlFor="perm-desc">Description</label>
        <textarea
          id="perm-desc"
          className="textarea"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
      </div>
      {error && <p className="error-text">{error}</p>}
    </Modal>
  );
}
