import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import PermissionChip from '../components/PermissionChip';
import { groupByModule } from '../utils/moduleColor';

export default function Users() {
  const { token, hasPermission } = useAuth();
  const showToast = useToast();

  const [users, setUsers] = useState([]);
  const [permissions, setPermissions] = useState([]);
  const [roles, setRoles] = useState([]);
  const [selectedUserId, setSelectedUserId] = useState(null);
  const [detail, setDetail] = useState(null);
  const [loading, setLoading] = useState(true);
  const [savingRoles, setSavingRoles] = useState(false);

  const canManage = hasPermission('users.manage_roles');

  useEffect(() => {
    (async () => {
      try {
        const [usersData, permissionsData, rolesData] = await Promise.all([
          api.getUsers(token),
          api.getPermissions(token),
          api.getRoles(token),
        ]);
        setUsers(usersData);
        setPermissions(permissionsData);
        setRoles(rolesData);
        if (usersData.length) setSelectedUserId(usersData[0].id);
      } finally {
        setLoading(false);
      }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    if (!selectedUserId) return;
    (async () => {
      const d = await api.getUserRoles(token, selectedUserId);
      setDetail(d);
    })();
  }, [selectedUserId, token]);

  async function toggleRole(roleId) {
    const currentIds = new Set(detail.roles.map((r) => r.role._id));
    currentIds.has(roleId) ? currentIds.delete(roleId) : currentIds.add(roleId);

    setSavingRoles(true);
    try {
      await api.updateUserRoles(token, selectedUserId, [...currentIds]);
      const refreshed = await api.getUserRoles(token, selectedUserId);
      setDetail(refreshed);
      showToast('Roles updated.');
    } catch (err) {
      showToast(err.message);
    } finally {
      setSavingRoles(false);
    }
  }

  async function setOverride(permissionId, action) {
    try {
      await api.updateUserOverride(token, selectedUserId, permissionId, action);
      const refreshed = await api.getUserRoles(token, selectedUserId);
      setDetail(refreshed);
      showToast('Permission override updated.');
    } catch (err) {
      showToast(err.message);
    }
  }

  const grouped = groupByModule(permissions);
  const selectedUser = users.find((u) => u.id === selectedUserId);
  const currentRoleIds = new Set((detail?.roles || []).map((r) => r.role._id));
  const overrideByPermId = new Map((detail?.permissionOverrides || []).map((o) => [o.permission._id, o.forbidden]));

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Users</h1>
          <p className="subtitle">Assign roles and set per-user permission overrides.</p>
        </div>
      </div>

      {loading ? (
        <p className="muted">Loading users…</p>
      ) : users.length === 0 ? (
        <div className="empty-state card">
          <h3>No users found</h3>
          <p>Register a user via the API to see them here.</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: '260px 1fr', gap: 16 }}>
          <div className="card" style={{ height: 'fit-content' }}>
            {users.map((u) => (
              <button
                key={u.id}
                onClick={() => setSelectedUserId(u.id)}
                style={{
                  display: 'block',
                  width: '100%',
                  textAlign: 'left',
                  padding: '12px 16px',
                  background: u.id === selectedUserId ? 'var(--signal-soft)' : 'transparent',
                  border: 'none',
                  borderBottom: '1px solid var(--border)',
                }}
              >
                <div style={{ fontSize: 14, fontWeight: 500 }}>{u.name}</div>
                <div className="muted" style={{ fontSize: 12 }}>
                  {u.email}
                </div>
              </button>
            ))}
          </div>

          {detail && selectedUser && (
            <div className="stack" style={{ gap: 16 }}>
              <div className="card card-pad">
                <h3 style={{ fontSize: 16 }}>{selectedUser.name}</h3>
                <p className="muted" style={{ fontSize: 13, marginBottom: 16 }}>
                  {selectedUser.email}
                </p>

                <div className="module-group-title">Roles</div>
                <div className="keyring" style={{ marginTop: 8 }}>
                  {roles.map((role) => (
                    <span
                      key={role._id}
                      className={`perm-chip selectable ${currentRoleIds.has(role._id) ? 'selected' : ''}`}
                      onClick={() => canManage && !savingRoles && toggleRole(role._id)}
                      style={{ fontFamily: 'var(--font-body)' }}
                    >
                      {role.name}
                    </span>
                  ))}
                </div>
              </div>

              <div className="card card-pad">
                <h3 style={{ fontSize: 16, marginBottom: 4 }}>Direct permission overrides</h3>
                <p className="muted" style={{ fontSize: 13, marginBottom: 16 }}>
                  Grant or forbid a specific permission for this user, bypassing their roles.
                </p>

                {Object.entries(grouped).map(([module, perms]) => (
                  <div key={module} className="module-group">
                    <div className="module-group-title">{module}</div>
                    <div className="stack" style={{ gap: 6 }}>
                      {perms.map((p) => {
                        const overrideState = overrideByPermId.has(p._id)
                          ? overrideByPermId.get(p._id)
                            ? 'forbid'
                            : 'grant'
                          : null;

                        return (
                          <div key={p._id} className="flex-row" style={{ justifyContent: 'space-between' }}>
                            <PermissionChip permission={p} />
                            <div className="flex-row" style={{ gap: 6 }}>
                              {overrideState && (
                                <span className={`badge ${overrideState === 'grant' ? 'badge-grant' : 'badge-forbid'}`}>
                                  {overrideState === 'grant' ? 'Granted' : 'Forbidden'}
                                </span>
                              )}
                              {canManage && (
                                <>
                                  <button
                                    className="btn-ghost"
                                    style={{ fontSize: 12, padding: '4px 8px' }}
                                    onClick={() => setOverride(p._id, 'grant')}
                                  >
                                    Grant
                                  </button>
                                  <button
                                    className="btn-ghost"
                                    style={{ fontSize: 12, padding: '4px 8px' }}
                                    onClick={() => setOverride(p._id, 'forbid')}
                                  >
                                    Forbid
                                  </button>
                                  {overrideState && (
                                    <button
                                      className="btn-ghost"
                                      style={{ fontSize: 12, padding: '4px 8px' }}
                                      onClick={() => setOverride(p._id, 'clear')}
                                    >
                                      Clear
                                    </button>
                                  )}
                                </>
                              )}
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
