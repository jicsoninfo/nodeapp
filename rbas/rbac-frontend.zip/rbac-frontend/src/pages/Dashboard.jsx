import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';

export default function Dashboard() {
  const { token, user } = useAuth();
  const [roles, setRoles] = useState([]);
  const [permissions, setPermissions] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    (async () => {
      try {
        const [rolesData, permissionsData, usersData] = await Promise.all([
          api.getRoles(token),
          api.getPermissions(token),
          api.getUsers(token).catch(() => []),
        ]);
        setRoles(rolesData);
        setPermissions(permissionsData);
        setUsers(usersData);
      } finally {
        setLoading(false);
      }
    })();
  }, [token]);

  const stats = [
    { label: 'Roles', value: roles.length, to: '/roles' },
    { label: 'Permissions', value: permissions.length, to: '/permissions' },
    { label: 'Users', value: users.length, to: '/users' },
  ];

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Welcome back, {user?.name?.split(' ')[0]}</h1>
          <p className="subtitle">Here's the current shape of access across the ERP.</p>
        </div>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))', gap: 14, marginBottom: 32 }}>
        {stats.map((s) => (
          <Link key={s.label} to={s.to} className="card card-pad" style={{ textDecoration: 'none', color: 'inherit' }}>
            <div className="muted" style={{ fontSize: 13 }}>
              {s.label}
            </div>
            <div style={{ fontFamily: 'var(--font-display)', fontSize: 32, fontWeight: 600, marginTop: 4 }}>
              {loading ? '—' : s.value}
            </div>
          </Link>
        ))}
      </div>

      <div className="card card-pad">
        <h3 style={{ fontSize: 16, marginBottom: 4 }}>Your access</h3>
        <p className="muted" style={{ fontSize: 13, marginBottom: 16 }}>
          Roles and permissions currently applied to your account.
        </p>

        <div className="stack" style={{ gap: 14 }}>
          <div>
            <div className="module-group-title">Roles</div>
            <div className="flex-row" style={{ flexWrap: 'wrap', gap: 8 }}>
              {user?.roles?.length ? (
                user.roles.map((r) => (
                  <span key={r} className="badge badge-custom">
                    {r}
                  </span>
                ))
              ) : (
                <span className="muted" style={{ fontSize: 13 }}>
                  No roles assigned.
                </span>
              )}
            </div>
          </div>
          <div>
            <div className="module-group-title">Permissions ({user?.permissions?.length || 0})</div>
            <div className="keyring">
              {user?.permissions?.slice(0, 20).map((p) => (
                <span key={p} className="perm-chip">
                  <span className="dot" style={{ background: 'var(--signal)' }} />
                  {p}
                </span>
              ))}
              {user?.permissions?.length > 20 && (
                <span className="muted" style={{ fontSize: 12, alignSelf: 'center' }}>
                  +{user.permissions.length - 20} more
                </span>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
