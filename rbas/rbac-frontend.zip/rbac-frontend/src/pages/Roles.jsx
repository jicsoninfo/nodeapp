import { useEffect, useState } from 'react';
import { api } from '../api/client';
import { useAuth } from '../context/AuthContext';
import { useToast } from '../context/ToastContext';
import Modal from '../components/Modal';
import PermissionChip from '../components/PermissionChip';
import { groupByModule } from '../utils/moduleColor';

export default function Roles() {
  const { token, hasPermission } = useAuth();
  const showToast = useToast();

  const [roles, setRoles] = useState([]);
  const [permissions, setPermissions] = useState([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState(null); // role object, or {} for new
  const [confirmDelete, setConfirmDelete] = useState(null);

  const canManage = hasPermission('roles.manage');

  async function refresh() {
    setLoading(true);
    try {
      const [rolesData, permissionsData] = await Promise.all([api.getRoles(token), api.getPermissions(token)]);
      setRoles(rolesData);
      setPermissions(permissionsData);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    refresh();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleDelete(role) {
    try {
      await api.deleteRole(token, role._id);
      showToast(`Role "${role.name}" deleted.`);
      setConfirmDelete(null);
      refresh();
    } catch (err) {
      showToast(err.message);
    }
  }

  return (
    <div className="page">
      <div className="page-header">
        <div>
          <h1>Roles</h1>
          <p className="subtitle">Bundles of permissions assigned to users across the ERP.</p>
        </div>
        {canManage && (
          <button className="btn btn-primary" onClick={() => setEditing({})}>
            + New role
          </button>
        )}
      </div>

      {loading ? (
        <p className="muted">Loading roles…</p>
      ) : roles.length === 0 ? (
        <div className="empty-state card">
          <h3>No roles yet</h3>
          <p>Create your first role to start granting access.</p>
        </div>
      ) : (
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(320px, 1fr))', gap: 14 }}>
          {roles.map((role) => {
            const coverage = permissions.length ? Math.round((role.permissions.length / permissions.length) * 100) : 0;
            return (
              <div key={role._id} className="card card-pad">
                <div className="flex-row" style={{ justifyContent: 'space-between' }}>
                  <div>
                    <div className="flex-row">
                      <h3 style={{ fontSize: 16 }}>{role.name}</h3>
                      {role.isSystem && <span className="badge badge-system">System</span>}
                    </div>
                    <p className="muted" style={{ fontSize: 13, marginTop: 4 }}>
                      {role.description || 'No description.'}
                    </p>
                  </div>
                </div>

                <div className="keyring">
                  {role.permissions.slice(0, 8).map((p) => (
                    <PermissionChip key={p._id} permission={p} />
                  ))}
                  {role.permissions.length > 8 && (
                    <span className="muted" style={{ fontSize: 12, alignSelf: 'center' }}>
                      +{role.permissions.length - 8} more
                    </span>
                  )}
                  {role.permissions.length === 0 && (
                    <span className="muted" style={{ fontSize: 13 }}>
                      No permissions granted.
                    </span>
                  )}
                </div>

                <div className="coverage-bar">
                  <div className="coverage-bar-fill" style={{ width: `${coverage}%` }} />
                </div>
                <div className="muted" style={{ fontSize: 12, marginTop: 6 }}>
                  {role.userCount} user{role.userCount === 1 ? '' : 's'} · {coverage}% of all permissions
                </div>

                {canManage && (
                  <div className="flex-row" style={{ marginTop: 16, gap: 8 }}>
                    <button className="btn btn-secondary" onClick={() => setEditing(role)} disabled={role.isSystem}>
                      Edit
                    </button>
                    <button
                      className="btn btn-danger"
                      onClick={() => setConfirmDelete(role)}
                      disabled={role.isSystem}
                    >
                      Delete
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {editing && (
        <RoleFormModal
          role={editing}
          permissions={permissions}
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            refresh();
          }}
        />
      )}

      {confirmDelete && (
        <Modal
          title={`Delete "${confirmDelete.name}"?`}
          onClose={() => setConfirmDelete(null)}
          footer={
            <>
              <button className="btn btn-secondary" onClick={() => setConfirmDelete(null)}>
                Cancel
              </button>
              <button className="btn btn-danger" onClick={() => handleDelete(confirmDelete)}>
                Delete role
              </button>
            </>
          }
        >
          <p className="muted" style={{ fontSize: 14 }}>
            Users holding this role will lose the permissions it grants. This can't be undone.
          </p>
        </Modal>
      )}
    </div>
  );
}

function RoleFormModal({ role, permissions, onClose, onSaved }) {
  const { token } = useAuth();
  const showToast = useToast();
  const isNew = !role._id;

  const [name, setName] = useState(role.name || '');
  const [description, setDescription] = useState(role.description || '');
  const [selectedIds, setSelectedIds] = useState(new Set((role.permissions || []).map((p) => p._id)));
  const [error, setError] = useState('');
  const [saving, setSaving] = useState(false);

  const grouped = groupByModule(permissions);

  function toggle(id) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!name.trim()) {
      setError('Role name is required.');
      return;
    }
    setSaving(true);
    setError('');
    try {
      const payload = { name, description, permissions: [...selectedIds] };
      if (isNew) {
        await api.createRole(token, payload);
        showToast(`Role "${name}" created.`);
      } else {
        await api.updateRole(token, role._id, payload);
        showToast(`Role "${name}" updated.`);
      }
      onSaved();
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <Modal
      title={isNew ? 'New role' : `Edit "${role.name}"`}
      onClose={onClose}
      footer={
        <>
          <button className="btn btn-secondary" onClick={onClose}>
            Cancel
          </button>
          <button className="btn btn-primary" onClick={handleSubmit} disabled={saving}>
            {saving ? 'Saving…' : isNew ? 'Create role' : 'Save changes'}
          </button>
        </>
      }
    >
      <div className="field">
        <label htmlFor="role-name">Role name</label>
        <input id="role-name" className="input" value={name} onChange={(e) => setName(e.target.value)} required />
      </div>
      <div className="field">
        <label htmlFor="role-desc">Description</label>
        <textarea
          id="role-desc"
          className="textarea"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        />
      </div>

      <div className="field">
        <label>Permissions</label>
        {Object.entries(grouped).map(([module, perms]) => (
          <div key={module} className="module-group">
            <div className="module-group-title">{module}</div>
            <div className="keyring" style={{ marginTop: 0 }}>
              {perms.map((p) => (
                <PermissionChip
                  key={p._id}
                  permission={p}
                  selected={selectedIds.has(p._id)}
                  onClick={() => toggle(p._id)}
                />
              ))}
            </div>
          </div>
        ))}
      </div>

      {error && <p className="error-text">{error}</p>}
    </Modal>
  );
}
