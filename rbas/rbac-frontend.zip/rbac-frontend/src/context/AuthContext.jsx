import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { api } from '../api/client';

const AuthContext = createContext(null);

export function AuthProvider({ children }) {
  const [token, setToken] = useState(() => localStorage.getItem('rbac_token'));
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadMe = useCallback(async (currentToken) => {
    try {
      const me = await api.me(currentToken);
      setUser(me);
    } catch {
      localStorage.removeItem('rbac_token');
      setToken(null);
      setUser(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (token) {
      loadMe(token);
    } else {
      setLoading(false);
    }
  }, [token, loadMe]);

  const login = useCallback(async (email, password) => {
    const { token: newToken } = await api.login(email, password);
    localStorage.setItem('rbac_token', newToken);
    setToken(newToken);
    await loadMe(newToken);
  }, [loadMe]);

  const logout = useCallback(() => {
    localStorage.removeItem('rbac_token');
    setToken(null);
    setUser(null);
  }, []);

  const hasPermission = useCallback(
    (slug) => Boolean(user?.permissions?.includes(slug)),
    [user]
  );

  const hasRole = useCallback((slug) => Boolean(user?.roles?.includes(slug)), [user]);

  const value = useMemo(
    () => ({ token, user, loading, login, logout, hasPermission, hasRole }),
    [token, user, loading, login, logout, hasPermission, hasRole]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used within AuthProvider');
  return ctx;
}
