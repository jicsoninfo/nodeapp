import { moduleColor } from '../utils/moduleColor';

export default function PermissionChip({ permission, selected, onClick, removable, onRemove }) {
  const clickable = Boolean(onClick);

  return (
    <span
      className={`perm-chip ${clickable ? 'selectable' : ''} ${selected ? 'selected' : ''}`}
      onClick={onClick}
      role={clickable ? 'button' : undefined}
      tabIndex={clickable ? 0 : undefined}
    >
      <span className="dot" style={{ background: selected ? '#fff' : moduleColor(permission.module) }} />
      {permission.slug}
      {removable && (
        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          style={{
            background: 'none',
            border: 'none',
            padding: 0,
            marginLeft: 2,
            color: 'inherit',
            opacity: 0.6,
            lineHeight: 1,
          }}
          aria-label={`Remove ${permission.slug}`}
        >
          ×
        </button>
      )}
    </span>
  );
}
