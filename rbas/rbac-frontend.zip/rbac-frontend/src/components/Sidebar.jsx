import { NavLink } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';

const NAV_ITEMS = [
  { to: '/', label: 'Dashboard', icon: '◧', end: true },
  { to: '/roles', label: 'Roles', icon: '⬡', permission: null, role: null },
  { to: '/permissions', label: 'Permissions', icon: '⌗' },
  { to: '/users', label: 'Users', icon: '◎' },
];

export default function Sidebar() {
  const { user, logout } = useAuth();

  return (
    <aside
      style={{
        background: 'var(--ink)',
        color: '#fff',
        padding: '24px 16px',
        display: 'flex',
        flexDirection: 'column',
        gap: 4,
      }}
    >
      <div style={{ padding: '4px 12px 28px' }}>
        <div style={{ fontFamily: 'var(--font-display)', fontWeight: 700, fontSize: 18, letterSpacing: '-0.01em' }}>
          ACCESS
        </div>
        <div style={{ fontSize: 12, color: '#8A93A6', marginTop: 2 }}>RBAC Console</div>
      </div>

      <nav style={{ display: 'flex', flexDirection: 'column', gap: 2 }}>
        {NAV_ITEMS.map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            style={({ isActive }) => ({
              display: 'flex',
              alignItems: 'center',
              gap: 10,
              padding: '9px 12px',
              borderRadius: 8,
              fontSize: 14,
              fontWeight: 500,
              color: isActive ? '#fff' : '#A6ADBC',
              background: isActive ? 'rgba(255,255,255,0.08)' : 'transparent',
              textDecoration: 'none',
            })}
          >
            <span aria-hidden style={{ fontSize: 15, width: 18, textAlign: 'center' }}>
              {item.icon}
            </span>
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div style={{ marginTop: 'auto', paddingTop: 20, borderTop: '1px solid rgba(255,255,255,0.08)' }}>
        <div style={{ padding: '0 12px' }}>
          <div style={{ fontSize: 13, fontWeight: 500, color: '#fff' }}>{user?.name}</div>
          <div style={{ fontSize: 12, color: '#8A93A6', marginBottom: 10 }}>{user?.email}</div>
        </div>
        <button
          onClick={logout}
          className="btn-ghost"
          style={{ color: '#A6ADBC', width: '100%', justifyContent: 'flex-start', fontSize: 13 }}
        >
          Sign out
        </button>
      </div>
    </aside>
  );
}
