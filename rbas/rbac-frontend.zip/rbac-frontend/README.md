# Access — RBAC Console (React frontend)

A React admin console for the Node.js/Express/MongoDB RBAC backend. Vite + React
Router, no UI kit — hand-built design system in `src/styles/index.css`.

## Design

- **Sidebar-driven admin layout**: dark ink sidebar, light content area.
- **Signature element — the "keyring"**: every role and permission list renders
  permissions as small mono-font chips with a module-colored dot, echoing the
  `module.action` slug format from the API. Role cards show a coverage bar (%
  of all permissions that role holds) alongside the chip cluster.
- **Type**: Space Grotesk for headings, Inter for body text, JetBrains Mono for
  permission slugs (since they read like code/config keys).
- Color-coded by ERP module: Sales (blue), Purchase (violet), Inventory (green),
  Accounting (amber), HR (coral), Reports (teal), System (gray).

## Pages

- **Login** — JWT auth against `/api/auth/login`.
- **Dashboard** — summary counts + the signed-in user's own roles/permissions.
- **Roles** — cards with the keyring visualization, create/edit modal with
  grouped permission checkboxes, delete with confirmation. System roles are
  locked from edit/delete.
- **Permissions** — table grouped by module, create/delete.
- **Users** — pick a user, toggle role assignment, and grant/forbid direct
  permission overrides per permission (mirrors the backend's override system).

## Setup

```bash
cd rbac-frontend
npm install
cp .env.example .env      # point VITE_API_URL at your running backend
npm run dev
```

Runs on `http://localhost:5173` by default. Make sure the Node/Express backend
(`rbac-node`) is running and seeded (`npm run seed` in that project) — log in
with `admin@example.com` / `ChangeMe123!`.

## Notes

- The `/auth/me` endpoint currently reports role-derived permissions only (not
  resolved through direct per-user overrides). If you want the dashboard's
  "Your access" panel to reflect overrides exactly, extend `authController.me`
  on the backend to call `rbac.hasPermission` per permission, or expose a
  dedicated "effective permissions" endpoint.
- All API calls live in `src/api/client.js` — swap `VITE_API_URL` for your
  deployed backend URL in production.
- No component library is used, so styling is fully owned by
  `src/styles/index.css` and can be restyled without fighting a framework's
  defaults.
